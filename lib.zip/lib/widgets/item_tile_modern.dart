import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../models/item.dart';

class ItemTileModern extends StatelessWidget {
  final ItemModel item;
  final VoidCallback? onTap;
  final VoidCallback? onCompleteHabit;
  final ValueChanged<bool?>? onToggleTodo;

  const ItemTileModern({
    super.key,
    required this.item,
    this.onTap,
    this.onCompleteHabit,
    this.onToggleTodo,
  });

  @override
  Widget build(BuildContext context) {
    final color = Color(item.color);
    final overdue = item.isOverdue;

    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap?.call();
      },
      child: Card(
        elevation: 3,
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              // Icon with background
              CircleAvatar(
                radius: 24,
                backgroundColor: color.withOpacity(0.15),
                child: Icon(_iconFor(item.type), color: color, size: 28),
              ),
              const SizedBox(width: 14),

              // Title + Subtitle
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: overdue ? Colors.red.shade700 : Colors.black87,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _subtitle(context),
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 12),

              // Trailing actions
              _buildTrailing(),
            ],
          ),
        ),
      ),
    );
  }

  /// Decide trailing widget based on type
  Widget _buildTrailing() {
    switch (item.type) {
      case ItemType.todo:
        return Checkbox(
          value: item.completed,
          onChanged: onToggleTodo,
          activeColor: Colors.indigo,
        );
      case ItemType.habit:
        return IconButton(
          icon: const Icon(Icons.local_fire_department, color: Colors.orange),
          tooltip: "Complete today (${item.streak})",
          onPressed: onCompleteHabit,
        );
      case ItemType.daySince:
        return Text(
          "${item.daysSince}d",
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
        );
    }
  }

  /// Subtitle depending on type
  String _subtitle(BuildContext context) {
    if (item.type == ItemType.habit) {
      var s = "Streak: ${item.streak}";
      if (item.remindAt != null) {
        // TimeOfDay.format requires a BuildContext
        s += " • ⏰ ${item.remindAt!.format(context)}";
      }
      return s;
    } else if (item.type == ItemType.todo) {
      final dueStr = item.due != null
          ? DateFormat('MMM d, y • h:mm a').format(item.due!.toLocal())
          : "";
      final priority = "Priority: ${item.priority.name}";
      return [dueStr, priority].where((p) => p.isNotEmpty).join(" • ");
    } else if (item.type == ItemType.daySince) {
      return "Since: ${item.baseline?.toLocal().toString().split(' ').first ?? "-"}";
    }
    return "";
  }

  /// Icon helper
  IconData _iconFor(ItemType type) {
    switch (type) {
      case ItemType.habit:
        return Icons.repeat;
      case ItemType.todo:
        return Icons.check_box_outlined;
      case ItemType.daySince:
        return Icons.timelapse;
    }
  }
}
