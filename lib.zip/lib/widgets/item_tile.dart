import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/item.dart';

IconData iconFor(ItemType type) {
  switch (type) {
    case ItemType.habit:
      return Icons.repeat;
    case ItemType.todo:
      return Icons.check_box_outlined;
    case ItemType.daySince:
      return Icons.timelapse;
  }
}

class ItemTile extends StatelessWidget {
  final ItemModel item;
  final VoidCallback? onTap;
  final VoidCallback? onCompleteHabit;
  final ValueChanged<bool?>? onToggleTodo;

  const ItemTile({
    super.key,
    required this.item,
    this.onTap,
    this.onCompleteHabit,
    this.onToggleTodo,
  });

  @override
  Widget build(BuildContext context) {
    final color = Color(item.color);
    final overdue = item.isOverdue;

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.15),
          child: Icon(iconFor(item.type), color: color),
        ),
        title: Text(
          item.title,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: overdue ? Colors.red : null,
          ),
        ),
        subtitle: _buildSubtitle(context), // ✅ Pass context here
        trailing: _buildTrailing(context),
        onTap: () {
          HapticFeedback.selectionClick();
          onTap?.call();
        },
      ),
    );
  }

  Widget? _buildTrailing(BuildContext context) {
    switch (item.type) {
      case ItemType.todo:
        return Checkbox(
          value: item.completed,
          onChanged: onToggleTodo,
        );
      case ItemType.habit:
        return IconButton(
          icon: const Icon(Icons.fireplace_outlined),
          tooltip: "Complete today (${item.streak})",
          onPressed: onCompleteHabit,
        );
      case ItemType.daySince:
        return Text(
          "${item.daysSince}d",
          style: const TextStyle(fontWeight: FontWeight.bold),
        );
    }
  }

  // ✅ Now accepts BuildContext so we can use it for TimeOfDay.format()
  Widget _buildSubtitle(BuildContext context) {
    final bits = <String>[];

    if (item.type == ItemType.habit) {
      bits.add("Streak: ${item.streak}");
      if (item.remindAt != null) {
        bits.add("⏰ ${item.remindAt!.format(context)}");
      }
    } else if (item.type == ItemType.todo) {
      if (item.due != null) bits.add("Due: ${item.due}");
      bits.add("Priority: ${item.priority.name}");
    } else if (item.type == ItemType.daySince) {
      bits.add(
        "Since: ${item.baseline?.toLocal().toString().split(' ').first}",
      );
    }

    return Text(bits.join(" • "));
  }
}
