import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/app_state.dart';
import 'services/item_provider.dart';
import 'screens/home_screen_modern.dart';
import 'screens/onboarding_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool seenOnboarding = false; // In production, persist with SharedPreferences

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState()),
        ChangeNotifierProvider(create: (_) => ItemProvider()), // ✅ added
      ],
      child: Consumer<AppState>(
        builder: (context, app, _) {
          final theme = ThemeData(
            colorSchemeSeed: app.accent,
            brightness: app.darkMode ? Brightness.dark : Brightness.light,
            useMaterial3: true,
          );
          return MaterialApp(
            title: 'Momentum',
            theme: theme,
            home: seenOnboarding
                ? const HomeScreenModern()
                : OnboardingScreen(
                    onDone: () => setState(() => seenOnboarding = true),
                  ),
          );
        },
      ),
    );
  }
}
