import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../services/sync_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool syncEnabled = SyncService.enabled;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: const Text("Dark Mode"),
            value: app.darkMode,
            onChanged: (v) => app.setTheme(dark: v, accentColor: app.accent),
          ),
          ListTile(
            title: const Text("Accent Color"),
            trailing: CircleAvatar(backgroundColor: app.accent),
            onTap: () async {
              final color = await showDialog<Color>(context: context, builder: (_) => const _AccentDialog());
              if (color != null) app.setTheme(dark: app.darkMode, accentColor: color);
            },
          ),
          const Divider(),
          SwitchListTile(
            title: const Text("Enable Cloud Sync (Firebase)"),
            value: syncEnabled,
            onChanged: (v) => setState(() => syncEnabled = v),
          ),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: () {
              SyncService.enabled = syncEnabled;
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved')));
            },
            child: const Text("Save"),
          )
        ],
      ),
    );
  }
}

class _AccentDialog extends StatelessWidget {
  const _AccentDialog();

  @override
  Widget build(BuildContext context) {
    final colors = [Colors.indigo, Colors.teal, Colors.orange, Colors.pink, Colors.green, Colors.cyan, Colors.amber];
    return AlertDialog(
      title: const Text("Pick Accent"),
      content: SizedBox(
        width: 300,
        child: Wrap(
          spacing: 12, runSpacing: 12,
          children: [
            for (final c in colors)
              GestureDetector(
                onTap: () => Navigator.pop(context, c),
                child: CircleAvatar(backgroundColor: c, radius: 18),
              )
          ],
        ),
      ),
    );
  }
}
