import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/item.dart';
import '../providers/app_state.dart';

class AddItemScreen extends StatefulWidget {
  const AddItemScreen({super.key});
  @override
  State<AddItemScreen> createState() => _AddItemScreenState();
}

class _AddItemScreenState extends State<AddItemScreen> {
  ItemType type = ItemType.habit;
  final titleCtrl = TextEditingController();
  final noteCtrl = TextEditingController();
  DateTime? due;
  TimeOfDay? remindAt;
  String? remindMsg;
  Priority priority = Priority.medium;
  Color color = Colors.indigo;
  DateTime? baseline;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Item")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<ItemType>(
            segments: const [
              ButtonSegment(value: ItemType.habit, label: Text('Habit'), icon: Icon(Icons.repeat)),
              ButtonSegment(value: ItemType.todo, label: Text('Todo'), icon: Icon(Icons.check_box_outlined)),
              ButtonSegment(value: ItemType.daySince, label: Text('Day Since'), icon: Icon(Icons.timelapse)),
            ],
            selected: {type},
            onSelectionChanged: (s) => setState(() => type = s.first),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: titleCtrl,
            decoration: const InputDecoration(labelText: "Title", border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: noteCtrl,
            decoration: const InputDecoration(labelText: "Note (optional)", border: OutlineInputBorder()),
            maxLines: 2,
          ),
          const SizedBox(height: 12),
          if (type == ItemType.todo) _duePicker(),
          if (type != ItemType.daySince) _reminderPicker(),
          if (type == ItemType.daySince) _baselinePicker(),
          const SizedBox(height: 12),
          DropdownButtonFormField<Priority>(
            value: priority,
            items: Priority.values.map((p) => DropdownMenuItem(value: p, child: Text(p.name))).toList(),
            onChanged: (v) => setState(() => priority = v ?? Priority.medium),
            decoration: const InputDecoration(labelText: "Priority", border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _save,
            child: const Text("Add"),
          )
        ],
      ),
    );
  }

  Widget _duePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Due (optional)"),
        Row(children: [
          OutlinedButton.icon(
            icon: const Icon(Icons.calendar_today),
            label: Text(due?.toLocal().toString().split('.').first ?? "Pick date & time"),
            onPressed: () async {
              final now = DateTime.now();
              final d = await showDatePicker(context: context, firstDate: now.subtract(const Duration(days: 365)), lastDate: now.add(const Duration(days: 365*5)), initialDate: now);
              if (d == null) return;
              final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
              if (t == null) return;
              setState(() => due = DateTime(d.year, d.month, d.day, t.hour, t.minute));
            },
          ),
        ]),
      ],
    );
  }

  Widget _reminderPicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Daily Reminder (optional)"),
        Row(
          children: [
            OutlinedButton.icon(
              icon: const Icon(Icons.alarm),
              label: Text(remindAt?.format(context) ?? "Pick time"),
              onPressed: () async {
                final t = await showTimePicker(context: context, initialTime: TimeOfDay.now());
                if (t != null) setState(() => remindAt = t);
              },
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                decoration: const InputDecoration(labelText: "Message", border: OutlineInputBorder()),
                onChanged: (v) => remindMsg = v,
              ),
            ),
          ],
        )
      ],
    );
  }

  Widget _baselinePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Baseline Date"),
        Row(children: [
          OutlinedButton.icon(
            icon: const Icon(Icons.event),
            label: Text(baseline?.toLocal().toString().split(' ').first ?? "Pick a date"),
            onPressed: () async {
              final now = DateTime.now();
              final d = await showDatePicker(context: context, firstDate: now.subtract(const Duration(days: 3650)), lastDate: now, initialDate: now);
              if (d != null) setState(() => baseline = d);
            },
          ),
        ]),
      ],
    );
  }

  Future<void> _save() async {
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    final app = context.read<AppState>();
    switch (type) {
      case ItemType.habit:
        await app.add(ItemModel.habit(title, color: color).copyWith(
          note: noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
          remindAt: remindAt,
          remindMessage: remindMsg,
          priority: priority,
        ));
        break;
      case ItemType.todo:
        await app.add(ItemModel.todo(title, due: due).copyWith(
          note: noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
          remindAt: remindAt,
          remindMessage: remindMsg,
          priority: priority,
        ));
        break;
      case ItemType.daySince:
        await app.add(ItemModel.daySince(title, baseline: baseline));
        break;
    }
    if (mounted) Navigator.pop(context);
  }
}
