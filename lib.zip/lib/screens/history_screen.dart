import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final map = app.habitCompletionsOverTime();
    final entries = map.entries.toList()..sort((a,b)=>a.key.compareTo(b.key));
    return Scaffold(
      appBar: AppBar(title: const Text('History')),
      body: ListView.builder(
        itemCount: entries.length,
        itemBuilder: (_, i) {
          final e = entries[i];
          return ListTile(
            leading: const Icon(Icons.calendar_month),
            title: Text("${e.key.toLocal().toString().split(' ').first}"),
            trailing: Text("+${e.value}"),
          );
        },
      ),
    );
  }
}
