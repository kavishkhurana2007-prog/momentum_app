import 'package:flutter/material.dart';

class OnboardingScreen extends StatelessWidget {
  final VoidCallback onDone;
  const OnboardingScreen({super.key, required this.onDone});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              const Text("Welcome to Habits & Todos", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text("• Track daily habits with streaks\n• Manage todos with due times\n• Get reminders, themes & analytics\n• Optional cloud sync & shared lists\n• Try AI time blocking to plan your day"),
              const Spacer(),
              FilledButton(
                onPressed: onDone,
                child: const Text("Get Started"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
