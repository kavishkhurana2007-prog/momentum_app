import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../models/item.dart';
import '../widgets/item_tile.dart';
import 'add_item_screen.dart';
import 'history_screen.dart';
import 'analytics_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final items = app.items;
    return Scaffold(
      appBar: AppBar(
        title: const Text("Habits & Todos"),
        actions: [
          IconButton(icon: const Icon(Icons.auto_awesome), tooltip: "AI Time Blocking", onPressed: () {
            final blocks = app.aiTimeBlocksForToday();
            showDialog(context: context, builder: (_) => AlertDialog(
              title: const Text("Suggested Plan Today"),
              content: SizedBox(
                width: 400,
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final b in blocks)
                      ListTile(
                        leading: const Icon(Icons.event),
                        title: Text(b.title),
                        subtitle: Text("${b.start.format(context)} - ${b.end.format(context)}"),
                      )
                  ],
                ),
              ),
            ));
          }),
          IconButton(icon: const Icon(Icons.bar_chart), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnalyticsScreen()))),
          IconButton(icon: const Icon(Icons.history), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen()))),
          IconButton(icon: const Icon(Icons.settings), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
        ],
      ),
      body: ReorderableListView.builder(
        itemCount: items.length,
        onReorder: (oldIndex, newIndex) {
          HapticFeedback.lightImpact();
          app.reorder(oldIndex, newIndex);
        },
        itemBuilder: (context, i) {
          final item = items[i];
          return Dismissible(
            key: ValueKey(item.id),
            background: Container(color: Colors.redAccent, alignment: Alignment.centerLeft, padding: const EdgeInsets.only(left: 24), child: const Icon(Icons.delete, color: Colors.white)),
            secondaryBackground: Container(color: Colors.redAccent, alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 24), child: const Icon(Icons.delete, color: Colors.white)),
            onDismissed: (_) => app.remove(item.id),
            child: ItemTile(
              item: item,
              onToggleTodo: (v) => app.toggleTodoComplete(item),
              onCompleteHabit: () => app.completeHabitToday(item),
              onTap: () => _editItem(context, item),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddItemScreen())),
        label: const Text("Add"),
        icon: const Icon(Icons.add),
      ),
    );
  }

  void _editItem(BuildContext context, ItemModel item) {
    // For brevity, reuse Add screen pattern with prefilled fields would be ideal.
    // Here we present a minimal quick edit dialog:
    final ctrl = TextEditingController(text: item.title);
    showDialog(context: context, builder: (_) {
      return AlertDialog(
        title: const Text("Edit"),
        content: TextField(controller: ctrl),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          FilledButton(onPressed: () {
            final app = context.read<AppState>();
            app.update(item.copyWith(title: ctrl.text.trim().isEmpty ? item.title : ctrl.text.trim()));
            Navigator.pop(context);
          }, child: const Text("Save"))
        ],
      );
    });
  }
}
