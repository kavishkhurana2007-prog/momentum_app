import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final map = app.habitCompletionsOverTime();
    final entries = map.entries.toList()..sort((a,b)=>a.key.compareTo(b.key));
    final todoRates = app.todoCompletionRates();

    return Scaffold(
      appBar: AppBar(title: const Text('Analytics')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text("Habit Consistency", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(
            height: 220,
            child: LineChart(LineChartData(
              titlesData: const FlTitlesData(show: false),
              lineBarsData: [
                LineChartBarData(
                  isCurved: true,
                  spots: [
                    for (int i=0; i<entries.length; i++) FlSpot(i.toDouble(), entries[i].value.toDouble())
                  ],
                )
              ],
            )),
          ),
          const SizedBox(height: 16),
          const Text("Todo Completion", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(
            height: 220,
            child: PieChart(PieChartData(sections: [
              PieChartSectionData(value: todoRates['done']!.toDouble(), title: 'Done'),
              PieChartSectionData(value: todoRates['pending']!.toDouble(),color: Colors.red, title: 'Pending'),
            ])),
          )
        ],
      ),
    );
  }
}
