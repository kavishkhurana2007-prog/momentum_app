import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/item.dart';
import '../widgets/item_tile_modern.dart';
import '../providers/app_state.dart'; // use the AppState that your main.dart provides

class HomeScreenModern extends StatelessWidget {
  const HomeScreenModern({super.key});

  @override
  Widget build(BuildContext context) {
    // Use AppState (already provided in main.dart)
    final app = context.watch<AppState>();
    final items = app.items;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.indigo,
        centerTitle: true,
        title: const Text(
          "Momentum", // renamed app title
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: items.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.hourglass_empty,
                      size: 80, color: Colors.grey.shade400),
                  const SizedBox(height: 12),
                  Text(
                    "No items yet!",
                    style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                return ItemTileModern(
                  item: item,
                  onTap: () {
                    // open detail/edit
                  },
                  onCompleteHabit: () {
                    // AppState has completeHabitToday(ItemModel)
                    app.completeHabitToday(item);
                  },
                  onToggleTodo: (val) {
                    // AppState has toggleTodoComplete(ItemModel)
                    app.toggleTodoComplete(item);
                  },
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        elevation: 6,
        backgroundColor: Colors.indigo,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text(
          "Add Item",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        onPressed: () {
          // open add-item page
        },
      ),
    );
  }
}
